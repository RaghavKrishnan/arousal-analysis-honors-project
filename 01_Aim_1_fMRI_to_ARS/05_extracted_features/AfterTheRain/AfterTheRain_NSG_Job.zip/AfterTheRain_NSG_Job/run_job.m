slidingFC('AfterTheRain');
exit;